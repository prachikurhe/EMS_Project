package com.yash.ems.report.converter;

import com.yash.ems.entity.Employee;
import com.yash.ems.entity.EmployeeFeedback;
import com.yash.ems.entity.EmployeeSkillsRating;
import com.yash.ems.entity.Skill;
import com.yash.ems.report.dto.SkillResponseDto;
import com.yash.ems.report.dto.UserReportDto;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

@Component
public class UserReportDtoConverter implements Converter<EmployeeFeedback, UserReportDto> {
    /**
     * @param feedback
     * @return
     */
    @Override
    public UserReportDto convert(EmployeeFeedback feedback) {
        UserReportDto userReportDto = new UserReportDto();


        if (isNull(feedback)) {
            return null;
        }

        Employee employee = feedback.getEmployee();
        if (nonNull(employee)) {
            userReportDto.setEmployeeId(employee.getEmployeeId());
            userReportDto.setEmployeeName(employee.getEmployeeName());
        }


        userReportDto.setFeedbackId(feedback.getId());
        userReportDto.setComments(feedback.getComments());
        userReportDto.setSuggestion(feedback.getSuggestion());
        userReportDto.setOverallExperience(feedback.getOverallExperience());
        userReportDto.setProjectExperience(feedback.getProjectExperience());
        userReportDto.setCreatedOn(feedback.getCreatedOn());
        userReportDto.setCreatedBy(nonNull(feedback.getCreatedBy()) ? feedback.getCreatedBy().getName() : "");
        userReportDto.setSkillResponseList(setSkillResponseList(feedback.getEmployeeSkillsRatings()));

        return userReportDto;
    }

    private List<SkillResponseDto> setSkillResponseList(List<EmployeeSkillsRating> employeeSkillsRatings) {
        List<SkillResponseDto> skillResponseDtoList = new ArrayList<>();
        if (nonNull(employeeSkillsRatings) && !employeeSkillsRatings.isEmpty()) {
            for (EmployeeSkillsRating skillsRating : employeeSkillsRatings) {
                SkillResponseDto skillResponseDto = new SkillResponseDto();
                Skill skill = skillsRating.getSkill();
                if(nonNull(skill)){
                    skillResponseDto.setSkillId(skill.getId());
                    skillResponseDto.setSkillName(skill.getName());
                }
                skillResponseDto.setRemarks(skillsRating.getRemarks());
                skillResponseDto.setRatingReceived(skillsRating.getRating());
                skillResponseDtoList.add(skillResponseDto);
            }
        }
        return skillResponseDtoList;
    }
}
