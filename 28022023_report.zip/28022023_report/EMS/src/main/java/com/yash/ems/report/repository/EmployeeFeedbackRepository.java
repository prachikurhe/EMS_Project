package com.yash.ems.report.repository;

import com.yash.ems.entity.EmployeeFeedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeFeedbackRepository extends JpaRepository<EmployeeFeedback, Integer> {
 List<EmployeeFeedback> findAllByOrderByIdDesc ();
}
