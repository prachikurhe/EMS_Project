package com.yash.ems.report.controller;

import com.yash.ems.report.dto.UserReportDto;
import com.yash.ems.report.service.ReportService;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * This class s used to expose rest api for report module.
 *
 * @author prachi.kurhe
 * @since 01-03-2023
 */
@RestController
@RequestMapping("/reports")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class ReportController {
    private final ReportService reportService;

    private static final Logger logger = LoggerFactory.getLogger(ReportController.class);


    /**
     * @param feedbackId  This is the unique id of employee.
     *
     * @return This will return user of report
     */
    @GetMapping("/{feedbackId}")
    @ApiOperation(value = "fetch report by feedbackId.")
    public UserReportDto getReportByFeedbackId(@PathVariable("feedbackId") int feedbackId) {
        String methodName = "getReportByFeedbackId()";
        logger.info(methodName + " called");
        return reportService.getReportByFeedBackId(feedbackId);
    }

    /**

     * @return This will return list of reports
     */
    @GetMapping
    @ApiOperation(value = "fetch all reports")
    public List<UserReportDto> getReports() {
        String methodName = "getAllReports()";
        logger.info(methodName + " called");

        return reportService.getReports();
    }

}
