package com.yash.ems.report.service.impl;

import com.yash.ems.entity.EmployeeFeedback;
import com.yash.ems.report.controller.ReportController;
import com.yash.ems.report.converter.UserReportDtoConverter;
import com.yash.ems.report.dto.UserReportDto;
import com.yash.ems.report.repository.EmployeeFeedbackRepository;
import com.yash.ems.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

@Service
@RequiredArgsConstructor
@Primary
public class ReportServiceImplNew implements ReportService {

    private static final Logger logger = LoggerFactory.getLogger(ReportServiceImpl.class);
    private final EmployeeFeedbackRepository feedbackRepository;
    private final UserReportDtoConverter userReportDtoConverter;
    /**
     * @param feedbackId
     * @return
     */
    @Override
    public UserReportDto getReportByFeedBackId(int feedbackId) {

        String methodName = "getReportByFeedBackId()";
        logger.info(methodName + " called");

        EmployeeFeedback employeeFeedback = feedbackRepository.findById(feedbackId).orElse(null);
        return userReportDtoConverter.convert(employeeFeedback);
    }

    /**
     * @return
     */
    @Override
    public List<UserReportDto> getReports() {

        String methodName = "getAllReports()";
        logger.info(methodName + " called");

        List<EmployeeFeedback> employeeFeedbacks = feedbackRepository.findAllByOrderByIdDesc();
        return convertList(employeeFeedbacks);
    }

    private List<UserReportDto> convertList(List<EmployeeFeedback> employeeFeedbacks){
        List<UserReportDto> userReportDtoList = new ArrayList<>();
        if(nonNull(employeeFeedbacks)){
            for (EmployeeFeedback employeeFeedback :employeeFeedbacks){
                if(nonNull(employeeFeedback))
                    userReportDtoList.add(userReportDtoConverter.convert(employeeFeedback));
            }
        }
        return userReportDtoList;
    }
}
