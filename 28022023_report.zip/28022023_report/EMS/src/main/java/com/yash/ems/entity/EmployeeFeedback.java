package com.yash.ems.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name="employee_feedback")
public class EmployeeFeedback implements Serializable{

	private static final long serialVersionUID = -5920333604782942132L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="overall_experience")
	private int overallExperience;
	
	@Column(name="project_experience")
	private int projectExperience;
	
	@Column(name="comments")
	private String comments;
	
	@Column(name="suggestion")
	private String suggestion;
	
	@Column(name="created_on")
	private LocalDateTime createdOn;
	
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="employee_id")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "employee_id", referencedColumnName = "id")
	@JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
	private Employee employee;
	
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="file_id")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "file_id", referencedColumnName = "id")
	@JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
	private EmployeeFeedbackFile employeeFeedbackFile;

//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="created_by_id")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "created_by_id", referencedColumnName = "id")
	@JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
	private User createdBy;
	
	@JsonManagedReference
	@OneToMany(targetEntity = EmployeeSkillsRating.class, cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "employee_feedback_id", referencedColumnName = "id")
	private List<EmployeeSkillsRating> employeeSkillsRatings;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getOverallExperience() {
		return overallExperience;
	}
	public void setOverallExperience(int overallExperience) {
		this.overallExperience = overallExperience;
	}
	public int getProjectExperience() {
		return projectExperience;
	}
	public void setProjctExperience(int projectExperience) {
		this.projectExperience = projectExperience;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestion() {
		return suggestion;
	}
	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}
	public LocalDateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public EmployeeFeedbackFile getEmployeeFeedbackFile() {
		return employeeFeedbackFile;
	}
	public void setEmployeeFeedbackFile(EmployeeFeedbackFile employeeFeedbackFile) {
		this.employeeFeedbackFile = employeeFeedbackFile;
	}
	public User getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	public List<EmployeeSkillsRating> getEmployeeSkillsRatings() {
		return employeeSkillsRatings;
	}
	public void setEmployeeSkillsRatings(List<EmployeeSkillsRating> employeeSkillsRatings) {
		this.employeeSkillsRatings = employeeSkillsRatings;
	}
}