package ems.report;

import com.yash.ems.entity.EmployeeFeedback;
import com.yash.ems.report.converter.UserReportDtoConverter;
import com.yash.ems.report.dto.UserReportDto;
import com.yash.ems.report.repository.EmployeeFeedbackRepository;
import com.yash.ems.report.service.ReportService;
import com.yash.ems.report.service.impl.ReportServiceImplNew;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import static ems.report.fixture.EmployeeFeedbackFixture.prepareEmployeeFeedback;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ReportServiceTest {

    private ReportService reportService;

    @BeforeEach
    void setUp(){
        reportService = new ReportServiceImplNew (feedbackRepository,
                new UserReportDtoConverter());
    }

    @Test
    void getAllFeedbacks(){

        EmployeeFeedback e1 = prepareEmployeeFeedback();
        when(feedbackRepository.findAllByOrderByIdDesc())
                .then(invocation -> List.of(e1));
        List<UserReportDto> reports = reportService.getReports();
    }


    @InjectMocks
   final private EmployeeFeedbackRepository feedbackRepository = new EmployeeFeedbackRepository() {
        @Override
        public List<EmployeeFeedback> findAllByOrderByIdDesc() {
            return null;
        }

        @Override
        public List<EmployeeFeedback> findAll() {
            return null;
        }

        @Override
        public List<EmployeeFeedback> findAll(Sort sort) {
            return null;
        }

        @Override
        public List<EmployeeFeedback> findAllById(Iterable<Integer> integers) {
            return null;
        }

        @Override
        public <S extends EmployeeFeedback> List<S> saveAll(Iterable<S> entities) {
            return null;
        }

        @Override
        public void flush() {

        }

        @Override
        public <S extends EmployeeFeedback> S saveAndFlush(S entity) {
            return null;
        }

        @Override
        public <S extends EmployeeFeedback> List<S> saveAllAndFlush(Iterable<S> entities) {
            return null;
        }

        @Override
        public void deleteAllInBatch(Iterable<EmployeeFeedback> entities) {

        }

        @Override
        public void deleteAllByIdInBatch(Iterable<Integer> integers) {

        }

        @Override
        public void deleteAllInBatch() {

        }

        @Override
        public EmployeeFeedback getOne(Integer integer) {
            return null;
        }

        @Override
        public EmployeeFeedback getById(Integer integer) {
            return null;
        }

        @Override
        public <S extends EmployeeFeedback> List<S> findAll(Example<S> example) {
            return null;
        }

        @Override
        public <S extends EmployeeFeedback> List<S> findAll(Example<S> example, Sort sort) {
            return null;
        }

        @Override
        public Page<EmployeeFeedback> findAll(Pageable pageable) {
            return null;
        }

        @Override
        public <S extends EmployeeFeedback> S save(S entity) {
            return null;
        }

        @Override
        public Optional<EmployeeFeedback> findById(Integer integer) {
            return Optional.empty();
        }

        @Override
        public boolean existsById(Integer integer) {
            return false;
        }

        @Override
        public long count() {
            return 0;
        }

        @Override
        public void deleteById(Integer integer) {

        }

        @Override
        public void delete(EmployeeFeedback entity) {

        }

        @Override
        public void deleteAllById(Iterable<? extends Integer> integers) {

        }

        @Override
        public void deleteAll(Iterable<? extends EmployeeFeedback> entities) {

        }

        @Override
        public void deleteAll() {

        }

        @Override
        public <S extends EmployeeFeedback> Optional<S> findOne(Example<S> example) {
            return Optional.empty();
        }

        @Override
        public <S extends EmployeeFeedback> Page<S> findAll(Example<S> example, Pageable pageable) {
            return null;
        }

        @Override
        public <S extends EmployeeFeedback> long count(Example<S> example) {
            return 0;
        }

        @Override
        public <S extends EmployeeFeedback> boolean exists(Example<S> example) {
            return false;
        }

        @Override
        public <S extends EmployeeFeedback, R> R findBy(Example<S> example, Function<FluentQuery.FetchableFluentQuery<S>, R> queryFunction) {
            return null;
        }
    };

}
