package ems.report.fixture;

import com.yash.ems.entity.*;

import java.time.LocalDateTime;
import java.util.List;

public class EmployeeFeedbackFixture {
    public static EmployeeFeedback prepareEmployeeFeedback(){
        EmployeeFeedback employeeFeedback = new EmployeeFeedback();
        Employee employee = new Employee();
//        employee.setCode("xyz");
        employee.setId(101);
        employee.setEmployeeId(employee.getId());
        employee.setEmployeeName("Prachi");
        employee.setExperience("3");
        employeeFeedback.setEmployee(employee);
        employeeFeedback.setComments("Good in java");
        User createdBy = new User();
        createdBy.setCode("xyz");
        createdBy.setId(202);
        createdBy.setName("Admin");
        createdBy.setEmail("admin@yash.com");
        createdBy.setPassword("pass");
        employeeFeedback.setCreatedBy(createdBy);
        employeeFeedback.setOverallExperience(3);
        employeeFeedback.setProjctExperience(3);
        employeeFeedback.setCreatedOn(LocalDateTime.now());
        employeeFeedback.setEmployeeSkillsRatings(List.of(
                prepareEmployeeSkillRaiting(1, "java", 4),
                prepareEmployeeSkillRaiting(2, "oracle", 4),
                prepareEmployeeSkillRaiting(2, "spring", 3)
                ));
        employeeFeedback.setEmployeeFeedbackFile(null);
        return employeeFeedback;
    }

    private static EmployeeSkillsRating prepareEmployeeSkillRaiting(int id, String skillName, int rating) {
        EmployeeSkillsRating skillsRating = new EmployeeSkillsRating();
        Skill skill = new Skill();
        skill.setId(id);
        skill.setName(skillName);
        skillsRating.setSkill(skill);
        skillsRating.setId(id+100);
        skillsRating.setRemarks("good in "+skillName);
        skillsRating.setRating(rating);
        return skillsRating;
    }
}
