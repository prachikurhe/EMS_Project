package ems;

//@SpringBootTest
class ReportApplicationTests {


//	@Test
	void contextLoads() {
	}



}
