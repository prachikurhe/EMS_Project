# EMS
Its a Employee Management System used by competancy team to onboard a employee,upload feedback,serach feedback and generate report
